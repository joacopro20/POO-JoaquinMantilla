/**
 * 
 */
/**
 * 
 */
module MyOutputVariableProject {
}